import './global.css';
import { Header } from './components/Header';
import { ContentGrid } from './components/ContentGrid';
import { ContentRow } from './components/ContentRow';
import { Weather } from './components/Weather';
import { useEffect, useState } from 'react';

export default function App() {
  const [focusedIndex, setFocusedIndex] = useState(0);

  // Configure tailwind theme
  window.tailwind.config = {
    theme: {
      extend: {
        colors: {
          primary: 'hsl(var(--primary))',
          'primary-dark': 'hsl(var(--primary-dark))',
          'primary-light': 'hsl(var(--primary-light))',
          'accent-orange': 'hsl(var(--accent-orange))',
          'accent-blue': 'hsl(var(--accent-blue))',
          'text-primary': 'hsl(var(--text-primary))',
          'text-secondary': 'hsl(var(--text-secondary))',
          'text-tertiary': 'hsl(var(--text-tertiary))',
          'bg-card': 'hsl(var(--bg-card))',
          'bg-input': 'hsl(var(--bg-input))',
          'border-color': 'hsl(var(--border-color))',
        },
      },
    },
  };

  // Handle TV remote navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Handle remote directional keys
      if (e.key === 'ArrowUp' || e.key === 'ArrowDown' || e.key === 'ArrowLeft' || e.key === 'ArrowRight') {
        e.preventDefault();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary via-primary-light to-primary overflow-hidden">
      {/* Background decoration */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 right-0 w-96 h-96 bg-accent-orange/5 rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-accent-blue/5 rounded-full blur-3xl" />
      </div>

      {/* Main content optimized for TV */}
      <div className="relative z-10 h-screen flex flex-col">
        <Header />

        <main className="flex-1 overflow-y-auto px-12 py-12 space-y-16">
          {/* Featured content grid - 4 cards */}
          <ContentGrid />

          {/* Recent Watch row */}
          <ContentRow title="Recent Watch" />

          {/* Continue Watching row */}
          <ContentRow title="Continue Watching" />

          {/* Favorites row */}
          <ContentRow title="Favorites" />

          {/* Extra padding for bottom scrolling */}
          <div className="h-24" />
        </main>
      </div>

      {/* Weather widget - positioned fixed */}
      <Weather />
    </div>
  );
}
