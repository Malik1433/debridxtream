/**
 * Weather Component
 * Fixed position weather widget showing current temperature, time, and date
 * Displays in bottom right corner of the screen
 * Optimized for TV viewing
 */
import { motion } from 'framer-motion';
import { Cloud } from 'lucide-react';
import { useEffect, useState } from 'react';

export function Weather() {
  const [time, setTime] = useState<string>('');
  const [date, setDate] = useState<string>('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const hours = String(now.getHours()).padStart(2, '0');
      const minutes = String(now.getMinutes()).padStart(2, '0');
      const dayName = now.toLocaleDateString('en-US', { weekday: 'long' });
      const monthDay = now.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });

      setTime(`${hours}:${minutes}`);
      setDate(`${dayName}, ${monthDay}`);
    };

    updateTime();
    const interval = setInterval(updateTime, 60000);
    return () => clearInterval(interval);
  }, []);

  return (
    <motion.div
      className="fixed bottom-12 right-12 z-30"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: 0.5 }}
    >
      <div className="backdrop-blur-md bg-bg-card/40 border-2 border-border-color/30 rounded-3xl p-8 w-96 shadow-lg hover:shadow-xl transition-shadow outline-none ring-2 ring-transparent hover:ring-accent-orange/50 focus:ring-accent-orange cursor-pointer">
        {/* Weather icon and temperature */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <motion.div
              animate={{ y: [0, -5, 0] }}
              transition={{ duration: 3, repeat: Infinity }}
            >
              <Cloud size={44} className="text-accent-orange" />
            </motion.div>
            <span className="text-5xl font-light text-text-primary">24°</span>
          </div>
        </div>

        {/* Time display - TV sized */}
        <motion.div
          className="mb-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
        >
          <div className="text-6xl font-light text-text-primary tracking-tight leading-tight">
            {time}
          </div>
        </motion.div>

        {/* Date display */}
        <motion.div
          className="text-text-secondary text-2xl font-light"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
        >
          {date}
        </motion.div>

        {/* Decorative line */}
        <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-accent-orange to-transparent opacity-20" />
      </div>
    </motion.div>
  );
}
