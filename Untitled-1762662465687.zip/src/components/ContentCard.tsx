/**
 * ContentCard Component
 * Individual card for displaying content categories
 * Supports new badges, playing indicators, and background images
 * Optimized for TV remote navigation
 */
import { motion } from 'framer-motion';
import { Play } from 'lucide-react';
import { useState } from 'react';

interface ContentCardProps {
  id: number;
  title: string;
  subtitle: string;
  icon: string;
  isNew?: boolean;
  image?: string | null;
  isPlaying?: boolean;
  playingTitle?: string;
  delay?: number;
}

export function ContentCard({
  title,
  subtitle,
  icon,
  isNew = false,
  image = null,
  isPlaying = false,
  playingTitle = '',
  delay = 0,
}: ContentCardProps) {
  const [isFocused, setIsFocused] = useState(false);

  return (
    <motion.div
      className={`group relative h-80 rounded-3xl overflow-hidden cursor-pointer transition-all duration-300 outline-none ring-4 ${
        isFocused 
          ? 'ring-accent-orange scale-110 z-50' 
          : 'ring-transparent hover:scale-105'
      }`}
      onHoverStart={() => setIsFocused(true)}
      onHoverEnd={() => setIsFocused(false)}
      onFocus={() => setIsFocused(true)}
      onBlur={() => setIsFocused(false)}
      whileHover={{ y: isFocused ? -10 : 0 }}
      transition={{ duration: 0.3 }}
      tabIndex={0}
    >
      {/* Background gradient */}
      <div
        className="absolute inset-0 bg-gradient-to-br from-bg-card via-bg-card to-bg-input"
        style={{
          backgroundImage: image
            ? `url(${image}), linear-gradient(135deg, var(--bg-card), var(--bg-input))`
            : undefined,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      >
        {/* Overlay gradient */}
        <div className="absolute inset-0 bg-gradient-to-tr from-primary/80 via-primary/40 to-transparent" />
      </div>

      {/* Content */}
      <div className="relative h-full p-8 flex flex-col justify-between">
        {/* Top section - New badge or Playing indicator */}
        <div className="flex items-start justify-between">
          {isNew && (
            <motion.div
              className="bg-accent-orange text-white text-lg font-bold px-5 py-2 rounded-xl"
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: delay + 0.2, type: 'spring' }}
            >
              New
            </motion.div>
          )}

          {isPlaying && (
            <motion.div
              className="flex items-center gap-3 bg-black/40 backdrop-blur-sm px-5 py-2.5 rounded-xl"
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: delay + 0.2 }}
            >
              <Play size={18} className="text-accent-orange fill-accent-orange" />
              <span className="text-lg font-medium text-text-primary">Playing...</span>
            </motion.div>
          )}
        </div>

        {/* Middle section - Icon - TV sized */}
        <motion.div
          className="flex justify-center"
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: delay + 0.1, type: 'spring', stiffness: 100 }}
        >
          <div className="text-8xl opacity-80 group-hover:opacity-100 transition-opacity">
            {icon}
          </div>
        </motion.div>

        {/* Bottom section - Title and subtitle */}
        <div className="space-y-2">
          {playingTitle && (
            <p className="text-base text-text-secondary truncate group-hover:text-text-primary transition-colors">
              {playingTitle}
            </p>
          )}
          <h3 className="text-3xl font-semibold text-text-primary tracking-tight leading-tight">
            {title}
          </h3>
          <p className="text-lg text-text-secondary font-medium">{subtitle}</p>
        </div>
      </div>

      {/* Hover glow effect */}
      <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none rounded-2xl"
        style={{
          background: 'radial-gradient(circle at center, rgba(255, 127, 39, 0.1), transparent)',
        }}
      />

      {/* Border */}
      <div className="absolute inset-0 rounded-2xl border border-border-color/20 group-hover:border-border-color/40 transition-colors" />
    </motion.div>
  );
}
