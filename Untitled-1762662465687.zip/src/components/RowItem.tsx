/**
 * RowItem Component
 * Individual item displayed in ContentRow horizontal scrolling section
 * Shows thumbnail with progress bar and title on hover
 * Optimized for TV remote navigation
 */
import { motion } from 'framer-motion';
import { Play } from 'lucide-react';
import { useState } from 'react';

interface RowItemProps {
  id: number;
  title: string;
  progress: number;
  thumbnail: string;
}

export function RowItem({ title, progress, thumbnail }: RowItemProps) {
  const [isHovered, setIsHovered] = useState(false);
  const [isFocused, setIsFocused] = useState(false);

  return (
    <motion.div
      className={`relative flex-shrink-0 w-80 h-48 rounded-2xl overflow-hidden group cursor-pointer outline-none ring-4 transition-all duration-300 ${
        isFocused
          ? 'ring-accent-orange scale-110 z-50'
          : 'ring-transparent hover:scale-105'
      }`}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      onFocus={() => setIsFocused(true)}
      onBlur={() => setIsFocused(false)}
      whileHover={{ scale: isFocused ? 1.1 : 1.05, y: -10 }}
      transition={{ duration: 0.3 }}
      tabIndex={0}
    >
      {/* Thumbnail background */}
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: `url(${thumbnail})`,
          filter: 'brightness(0.8)',
        }}
      />

      {/* Overlay gradient */}
      <div className="absolute inset-0 bg-gradient-to-t from-primary via-transparent to-transparent opacity-60" />

      {/* Content */}
      <div className="absolute inset-0 p-6 flex flex-col justify-between">
        {/* Play button on hover */}
        <motion.div
          className="self-center mt-6"
          initial={{ opacity: 0, scale: 0 }}
          animate={isHovered || isFocused ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0 }}
          transition={{ duration: 0.2 }}
        >
          <div className="w-16 h-16 bg-accent-orange/90 hover:bg-accent-orange rounded-full flex items-center justify-center backdrop-blur-sm shadow-lg">
            <Play size={28} className="text-white fill-white" />
          </div>
        </motion.div>

        {/* Title at bottom */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={isHovered || isFocused ? { opacity: 1, y: 0 } : { opacity: 0, y: 10 }}
          transition={{ duration: 0.2 }}
        >
          <p className="text-lg font-semibold text-text-primary truncate">{title}</p>
        </motion.div>
      </div>

      {/* Progress bar */}
      {progress > 0 && (
        <div className="absolute bottom-0 left-0 right-0 h-2 bg-bg-input/50">
          <motion.div
            className="h-full bg-gradient-to-r from-accent-orange to-accent-blue"
            initial={{ width: 0 }}
            whileInView={{ width: `${progress}%` }}
            viewport={{ once: true }}
            transition={{ duration: 1, delay: 0.2 }}
          />
        </div>
      )}

      {/* Border */}
      <div className={`absolute inset-0 rounded-2xl border-2 transition-all duration-300 ${
        isFocused
          ? 'border-accent-orange'
          : 'border-border-color/20 group-hover:border-border-color/50'
      }`} />
    </motion.div>
  );
}
