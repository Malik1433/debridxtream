/**
 * ContentRow Component
 * Displays horizontal scrolling rows of content items
 * Used for Recent Watch, Continue Watching, and Favorites sections
 */
import { motion } from 'framer-motion';
import { ChevronRight } from 'lucide-react';
import { RowItem } from './RowItem';

interface ContentRowProps {
  title: string;
}

const generateMockItems = (count: number) => {
  const titles = [
    'The Matrix',
    'Inception',
    'Interstellar',
    'Dune',
    'Avatar',
    'Oppenheimer',
    'Barbie',
    'Killers of the Flower Moon',
  ];

  return Array.from({ length: count }, (_, i) => ({
    id: i + 1,
    title: titles[i % titles.length],
    progress: Math.floor(Math.random() * 100),
    thumbnail: `https://images.unsplash.com/photo-${1500000000000 + i}?w=400&h=250&fit=crop`,
  }));
};

export function ContentRow({ title }: ContentRowProps) {
  const items = generateMockItems(8);

  return (
    <motion.div
      className="mb-16"
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-100px' }}
      transition={{ duration: 0.6 }}
    >
      {/* Row header - TV optimized */}
      <div className="flex items-center justify-between mb-8">
        <h2 className="text-4xl font-semibold text-text-primary tracking-tight">
          {title}
        </h2>
        <button className="flex items-center gap-3 text-accent-orange hover:text-accent-orange/80 transition-colors text-xl font-medium px-6 py-3 hover:bg-accent-orange/10 rounded-lg outline-none ring-2 ring-transparent hover:ring-accent-orange/50 focus:ring-accent-orange">
          View All
          <ChevronRight size={24} />
        </button>
      </div>

      {/* Scrollable container - TV optimized */}
      <div className="relative group">
        <motion.div
          className="flex gap-6 overflow-x-auto pb-6 snap-x snap-mandatory scroll-smooth"
          style={{ scrollBehavior: 'smooth', scrollPaddingLeft: '48px' }}
        >
          {items.map((item, index) => (
            <motion.div
              key={item.id}
              className="flex-shrink-0 snap-start"
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{
                duration: 0.5,
                delay: index * 0.05,
              }}
            >
              <RowItem {...item} />
            </motion.div>
          ))}
        </motion.div>

        {/* Gradient fade effect */}
        <div className="absolute right-0 top-0 bottom-6 w-16 bg-gradient-to-l from-primary to-transparent pointer-events-none rounded-r-lg" />
      </div>
    </motion.div>
  );
}
