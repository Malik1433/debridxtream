/**
 * ContentGrid Component
 * Displays 4 featured content cards in a grid layout
 * Shows categories: Live TV, Movies, Series, and Debrid
 * Optimized for Android TV and Fire TV Sticks
 */
import { motion } from 'framer-motion';
import { ContentCard } from './ContentCard';

const contentItems = [
  {
    id: 1,
    title: 'Live TV',
    subtitle: '+5000 Channels',
    icon: '📺',
    isNew: false,
    image: null,
  },
  {
    id: 2,
    title: 'Movies',
    subtitle: '+2500 Titles',
    icon: '🎬',
    isNew: true,
    image: null,
  },
  {
    id: 3,
    title: 'Series',
    subtitle: '+1200 Shows',
    icon: '📺',
    isNew: false,
    image: null,
    isPlaying: true,
    playingTitle: 'Breaking Bad Season 5',
  },
  {
    id: 4,
    title: 'Debrid',
    subtitle: 'Premium Content',
    icon: '⚡',
    isNew: false,
    image: null,
  },
];

export function ContentGrid() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5,
        ease: 'easeOut',
      },
    },
  };

  return (
    <motion.div
      className="grid grid-cols-2 lg:grid-cols-4 gap-8 mb-16"
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      {contentItems.map((item, index) => (
        <motion.div key={item.id} variants={itemVariants}>
          <ContentCard {...item} delay={index * 0.05} />
        </motion.div>
      ))}
    </motion.div>
  );
}
