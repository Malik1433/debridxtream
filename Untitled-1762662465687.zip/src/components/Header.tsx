/**
 * Header Component
 * Displays the app logo, search bar, and user profile/settings
 * Optimized for Android TV and Firestick remotes
 */
import { Search, Settings } from 'lucide-react';
import { useState } from 'react';

export function Header() {
  const [isSearchFocused, setIsSearchFocused] = useState(false);

  return (
    <header className="sticky top-0 z-20 backdrop-blur-md bg-primary/50 border-b border-border-color/20 py-6 px-12">
      <div className="flex items-center justify-between gap-12">
        {/* Logo - TV optimized size */}
        <div className="flex items-center gap-3 flex-shrink-0">
          <div className="text-4xl font-bold text-text-primary tracking-tight">
            MI
            <span className="text-base font-medium text-text-secondary ml-2">IPTV</span>
          </div>
        </div>

        {/* Search bar - larger for TV remotes */}
        <div className="flex-1 max-w-2xl">
          <div className={`flex items-center gap-4 backdrop-blur-sm rounded-2xl px-6 py-4 border-2 transition-all duration-300 ${
            isSearchFocused
              ? 'bg-bg-input/80 border-accent-orange'
              : 'bg-bg-input/40 border-border-color/20'
          }`}>
            <div className="w-10 h-10 bg-bg-card rounded-full flex items-center justify-center flex-shrink-0">
              <Search size={22} className="text-accent-orange" />
            </div>
            <input
              type="text"
              placeholder="Search"
              onFocus={() => setIsSearchFocused(true)}
              onBlur={() => setIsSearchFocused(false)}
              className="bg-transparent text-text-primary placeholder-text-tertiary outline-none w-full text-xl font-medium"
            />
          </div>
        </div>

        {/* Right controls - larger buttons for TV remotes */}
        <div className="flex items-center gap-6 flex-shrink-0">
          {/* Settings button */}
          <button className="w-16 h-16 rounded-full bg-bg-card/50 hover:bg-accent-orange/20 focus:bg-accent-orange/30 transition-all duration-200 flex items-center justify-center group outline-none ring-2 ring-transparent hover:ring-accent-orange/50 focus:ring-accent-orange">
            <Settings size={28} className="text-text-secondary group-hover:text-accent-orange transition-colors" />
          </button>

          {/* User profile */}
          <button className="w-16 h-16 rounded-full bg-gradient-to-br from-red-500 via-red-600 to-red-700 hover:shadow-xl focus:shadow-xl transition-all duration-200 flex items-center justify-center flex-shrink-0 overflow-hidden outline-none ring-2 ring-transparent hover:ring-red-400/50 focus:ring-red-400">
            <div className="w-full h-full rounded-full flex items-center justify-center">
              <span className="text-3xl">👨</span>
            </div>
          </button>
        </div>
      </div>
    </header>
  );
}
