package com.tvonnet.debridxtreamiptv.data.epg

import android.content.Context
import android.util.Log
import com.tvonnet.debridxtreamiptv.data.model.EpgProgram
import com.tvonnet.debridxtreamiptv.utils.memory.MemoryManager
import kotlinx.coroutines.*
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.io.PushbackReader
import java.io.Reader
import java.io.StringReader

object EpgParser {
    private const val TAG = "EpgParser"
    private const val DEFAULT_XML_DECLARATION = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
    private const val PROBE_SIZE_CHARS = 4096

    private lateinit var memoryManager: MemoryManager
    private var parsingJob: Job? = null

    fun initialize(context: Context) {
        memoryManager = MemoryManager.getInstance(context)
        memoryManager.addMemoryPressureCallback(object : MemoryManager.MemoryPressureCallback {
            override suspend fun onMemoryPressure(level: MemoryManager.MemoryPressure) {
                if (level == MemoryManager.MemoryPressure.CRITICAL) {
                    Log.w(TAG, "Critical memory pressure detected, cancelling EPG parsing")
                    parsingJob?.cancel()
                }
            }
        })
    }

    suspend fun parse(xmlContent: String): Map<String, List<EpgProgram>> {
        // Check if content is too large for memory
        val maxSize = memoryManager.getMaxParsingSize()
        if (xmlContent.length > maxSize) {
            Log.e(TAG, "XML content too large: ${xmlContent.length} bytes > $maxSize bytes")
            return emptyMap()
        }

        return try {
            parse(StringReader(xmlContent))
        } catch (e: OutOfMemoryError) {
            Log.e(TAG, "EPG parsing failed due to memory constraints. XML content too large.", e)
            memoryManager.requestGarbageCollection()
            emptyMap()
        } catch (e: CancellationException) {
            Log.i(TAG, "EPG parsing cancelled due to memory pressure")
            emptyMap()
        } catch (e: Exception) {
            Log.e(TAG, "EPG parsing failed", e)
            emptyMap()
        }
    }

    suspend fun parseInputStream(inputStream: InputStream): Map<String, List<EpgProgram>> {
        return try {
            parse(InputStreamReader(inputStream, Charsets.UTF_8))
        } catch (e: OutOfMemoryError) {
            Log.e(TAG, "EPG parsing failed due to memory constraints.", e)
            memoryManager.requestGarbageCollection()
            emptyMap()
        } catch (e: CancellationException) {
            Log.i(TAG, "EPG parsing cancelled due to memory pressure")
            emptyMap()
        } catch (e: Exception) {
            Log.e(TAG, "EPG parsing failed", e)
            emptyMap()
        }
    }

    suspend fun parse(reader: Reader): Map<String, List<EpgProgram>> {
        val epgMap = mutableMapOf<String, MutableList<EpgProgram>>()
        parseStream(reader) { program ->
            val list = epgMap.getOrPut(program.channelId) { mutableListOf() }
            list.add(program)
        }
        return epgMap
    }

    /**
     * Stream XML and invoke callback for every programme parsed.
     * Uses streaming parser with minimal memory footprint.
     * Returns the total number of programmes encountered.
     */
    suspend fun parseStream(reader: Reader, onProgram: suspend (EpgProgram) -> Unit): Int {
        var programCount = 0
        var skippedInvalidTags = 0

        parsingJob = CoroutineScope(Dispatchers.IO).launch {
            try {
                val chunkSize = memoryManager.getOptimalChunkSize()
                val bufferedReader = BufferedReader(reader, chunkSize)
                val xmlFactory = XmlPullParserFactory.newInstance()
                xmlFactory.isNamespaceAware = false
                val parser = xmlFactory.newPullParser()

                // Create a custom Reader that processes XML declarations on-the-fly
                val processedReader = createXmlDeclarationFixingReader(bufferedReader)
                parser.setInput(processedReader)

                var eventType = parser.eventType
                var currentProgram: EpgProgram? = null

                while (eventType != XmlPullParser.END_DOCUMENT && isActive) {
                    try {
                        when (eventType) {
                            XmlPullParser.START_TAG -> {
                                when (parser.name) {
                                    "programme" -> {
                                        currentProgram = EpgProgram(
                                            channelId = parser.getAttributeValue(null, "channel") ?: "",
                                            start = parseTimestamp(parser.getAttributeValue(null, "start")),
                                            stop = parseTimestamp(parser.getAttributeValue(null, "stop")),
                                            title = null,
                                            desc = null,
                                            category = null
                                        )
                                    }
                                    "title" -> {
                                        val titleText = parser.nextText()
                                        currentProgram = currentProgram?.copy(title = cleanTextContent(titleText))
                                    }
                                    "desc" -> {
                                        val descText = parser.nextText()
                                        currentProgram = currentProgram?.copy(desc = cleanTextContent(descText))
                                    }
                                    "category" -> {
                                        val categoryText = parser.nextText()
                                        currentProgram = currentProgram?.copy(category = cleanTextContent(categoryText))
                                    }
                                    // Skip invalid HTML/JavaScript tags
                                    "a", "script", "style", "noscript", "iframe", "object", "embed" -> {
                                        Log.w(TAG, "Skipping invalid HTML tag: ${parser.name}")
                                        skippedInvalidTags++
                                        skipToEndTag(parser, parser.name)
                                    }
                                }
                            }
                            XmlPullParser.END_TAG -> {
                                if (parser.name == "programme") {
                                    currentProgram?.let { program ->
                                        if (program.channelId.isNotEmpty()) {
                                            onProgram(program)
                                            programCount++

                                            // Yield to avoid blocking and allow cancellation
                                            yield()

                                            // Check memory pressure periodically
                                            if (programCount % 100 == 0) {
                                                val pressure = memoryManager.checkMemoryPressure()
                                                if (pressure == MemoryManager.MemoryPressure.CRITICAL) {
                                                    Log.w(TAG, "Critical memory pressure, stopping EPG parsing")
                                                    return@launch
                                                }
                                            }
                                        }
                                    }
                                    currentProgram = null
                                }
                            }
                        }
                        eventType = parser.next()

                    } catch (tagException: Exception) {
                        Log.w(TAG, "Error parsing tag, continuing...", tagException)
                        try {
                            eventType = parser.next()
                        } catch (recoveryException: Exception) {
                            Log.e(TAG, "Failed to recover from parsing error", recoveryException)
                            break
                        }
                    }
                }

                if (skippedInvalidTags > 0) {
                    Log.i(TAG, "EPG parsing completed: $programCount programs, skipped $skippedInvalidTags invalid tags")
                }

            } catch (e: OutOfMemoryError) {
                Log.e(TAG, "EPG parsing failed due to memory constraints", e)
                memoryManager.requestGarbageCollection()
            } catch (e: CancellationException) {
                Log.i(TAG, "EPG parsing cancelled")
            } catch (e: Exception) {
                Log.e(TAG, "EPG parsing failed", e)
            }
        }

        try {
            parsingJob?.join()
        } catch (e: CancellationException) {
            Log.i(TAG, "EPG parsing join cancelled")
        }

        return programCount
    }

    /**
     * Creates a Reader that fixes XML declaration issues on-the-fly
     */
    private fun createXmlDeclarationFixingReader(reader: BufferedReader): Reader {
        // NOTE: Previous implementation used readLine() which can load huge "single-line" XMLTV files into memory,
        // causing OOM (common on TV devices). This version is truly streaming and never buffers the full document.

        val pushbackReader = PushbackReader(reader, PROBE_SIZE_CHARS)

        val probe = CharArray(PROBE_SIZE_CHARS)
        val probeRead = pushbackReader.read(probe).coerceAtLeast(0)
        if (probeRead > 0) {
            pushbackReader.unread(probe, 0, probeRead)
        }

        val (hasXmlDeclAtStart, needsXmlDecl) = detectDeclarationState(probe, probeRead)
        val strippingReader = XmlDeclarationStrippingReader(
            source = pushbackReader,
            initialSeenXmlDeclaration = hasXmlDeclAtStart || needsXmlDecl
        )

        return if (needsXmlDecl) {
            Log.w(TAG, "Missing XML declaration, adding in streaming mode...")
            ChainedReader(StringReader("$DEFAULT_XML_DECLARATION\n"), strippingReader)
        } else {
            strippingReader
        }
    }

    private fun detectDeclarationState(sample: CharArray, length: Int): Pair<Boolean, Boolean> {
        if (length <= 0) return false to false
        var i = 0
        // Skip BOM and leading whitespace
        while (i < length) {
            val c = sample[i]
            if (c == '\uFEFF' || c == '\u0000') {
                i++
                continue
            }
            if (!c.isWhitespace()) break
            i++
        }
        if (i >= length) return false to false

        // XML declaration must appear at the very start of the document (ignoring BOM).
        val hasXmlDeclAtStart = startsWithIgnoreCase(sample, length, i, "<?xml")
        val firstIsTagStart = sample[i] == '<'
        val needsXmlDecl = firstIsTagStart && !hasXmlDeclAtStart
        return hasXmlDeclAtStart to needsXmlDecl
    }

    private fun startsWithIgnoreCase(sample: CharArray, length: Int, start: Int, prefix: String): Boolean {
        if (start + prefix.length > length) return false
        for (j in prefix.indices) {
            val a = sample[start + j].lowercaseChar()
            val b = prefix[j].lowercaseChar()
            if (a != b) return false
        }
        return true
    }

    /**
     * Streaming reader that strips *extra* XML declarations (<?xml ... ?>) found after the first one.
     * This prevents XmlPullParser from failing on broken providers while keeping memory usage minimal.
     */
    private class XmlDeclarationStrippingReader(
        private val source: Reader,
        initialSeenXmlDeclaration: Boolean
    ) : Reader() {

        private var seenXmlDeclaration: Boolean = initialSeenXmlDeclaration
        private var isStart: Boolean = true
        private val pending = CharArray(16)
        private var pendingLen = 0
        private var pendingPos = 0

        override fun read(cbuf: CharArray, off: Int, len: Int): Int {
            if (len == 0) return 0

            var out = off
            var remaining = len

            while (remaining > 0) {
                val fromPending = drainPending(cbuf, out, remaining)
                if (fromPending > 0) {
                    out += fromPending
                    remaining -= fromPending
                    continue
                }

                val chInt = source.read()
                if (chInt == -1) break
                var ch = chInt.toChar()

                // Drop BOM at stream start.
                if (isStart && ch == '\uFEFF') continue
                if (!ch.isWhitespace()) isStart = false

                if (ch != '<') {
                    cbuf[out++] = ch
                    remaining--
                    continue
                }

                // Possible processing instruction.
                val nextInt = source.read()
                if (nextInt == -1) {
                    cbuf[out++] = '<'
                    remaining--
                    break
                }
                val next = nextInt.toChar()

                if (next != '?') {
                    // Normal tag, emit both chars.
                    if (remaining >= 2) {
                        cbuf[out++] = '<'
                        cbuf[out++] = next
                        remaining -= 2
                    } else {
                        cbuf[out++] = '<'
                        remaining--
                        pushPending(next)
                    }
                    continue
                }

                // We have "<?", look for "<?xml" (case-insensitive).
                val probe = CharArray(3)
                val read3 = source.read(probe, 0, 3)
                if (read3 < 3) {
                    // Not enough to decide; emit what we got.
                    emitChars('<', '?', *probe.copyOf(read3))
                    continue
                }

                val isXml = probe[0].lowercaseChar() == 'x' &&
                    probe[1].lowercaseChar() == 'm' &&
                    probe[2].lowercaseChar() == 'l'

                if (!isXml) {
                    emitChars('<', '?', probe[0], probe[1], probe[2])
                    continue
                }

                if (seenXmlDeclaration) {
                    // Skip this extra XML declaration entirely (until "?>").
                    skipUntilProcessingInstructionEnd()
                    continue
                }

                // Keep the first xml declaration.
                seenXmlDeclaration = true
                emitChars('<', '?', probe[0], probe[1], probe[2])
            }

            val written = out - off
            return if (written == 0) -1 else written
        }

        private fun drainPending(dest: CharArray, off: Int, len: Int): Int {
            val available = pendingLen - pendingPos
            if (available <= 0) return 0
            val n = minOf(available, len)
            pending.copyInto(dest, destinationOffset = off, startIndex = pendingPos, endIndex = pendingPos + n)
            pendingPos += n
            if (pendingPos >= pendingLen) {
                pendingPos = 0
                pendingLen = 0
            }
            return n
        }

        private fun pushPending(c: Char) {
            if (pendingLen >= pending.size) {
                // Pending should remain tiny; if it ever grows, just drop (best-effort stream sanitization).
                return
            }
            pending[pendingLen++] = c
        }

        private fun emitChars(vararg chars: Char) {
            // Push into pending so caller's loop will drain them into the output buffer.
            for (c in chars) pushPending(c)
        }

        private fun skipUntilProcessingInstructionEnd() {
            var prevWasQuestion = false
            while (true) {
                val i = source.read()
                if (i == -1) return
                val c = i.toChar()
                if (prevWasQuestion && c == '>') return
                prevWasQuestion = c == '?'
            }
        }

        override fun close() {
            source.close()
        }
    }

    private class ChainedReader(
        private val first: Reader,
        private val second: Reader
    ) : Reader() {
        private var usingFirst = true

        override fun read(cbuf: CharArray, off: Int, len: Int): Int {
            if (!usingFirst) return second.read(cbuf, off, len)
            val n = first.read(cbuf, off, len)
            if (n != -1) return n
            usingFirst = false
            return second.read(cbuf, off, len)
        }

        override fun close() {
            try {
                first.close()
            } finally {
                second.close()
            }
        }
    }

    /**
     * Pre-process XML content to remove problematic HTML/JavaScript content
     */
    private fun preprocessXml(xmlContent: String): String {
        return xmlContent
            // Remove Cloudflare email protection tags
            .replace(Regex("<a[^>]*class=[\"'][^\"']*__cf_email__[^\"']*[\"'][^>]*>[^<]*</a>"), "")
            // Remove script tags and their content
            .replace(Regex("<script[^>]*>.*?</script>", setOf(RegexOption.DOT_MATCHES_ALL)), "")
            // Remove noscript tags
            .replace(Regex("<noscript[^>]*>.*?</noscript>", setOf(RegexOption.DOT_MATCHES_ALL)), "")
            // Remove style tags
            .replace(Regex("<style[^>]*>.*?</style>", setOf(RegexOption.DOT_MATCHES_ALL)), "")
            // Remove HTML comments that might contain JavaScript
            .replace(Regex("<!--.*?-->", setOf(RegexOption.DOT_MATCHES_ALL)), "")
            // Remove data-cfemail attributes
            .replace(Regex("data-cfemail=[\"'][^\"']*[\"']"), "")
            // Remove cdn-cgi/l/email-protection hrefs
            .replace(Regex("href=[\"'][^\"']*cdn-cgi/l/email-protection[^\"']*[\"']"), "")
    }

    /**
     * Phase 2.8: Fix multiple XML declarations issue
     */
    private fun fixMultipleXmlDeclarations(xmlContent: String): String {
        val xmlDeclaration = Regex("""<\?xml[^>]*\?>""")
        val declarations = xmlDeclaration.findAll(xmlContent).toList()

        if (declarations.size <= 1) {
            return xmlContent
        }

        Log.w(TAG, "Found ${declarations.size} XML declarations, keeping only the first")
        val firstDeclaration = declarations.first().value

        // Remove all declarations and add back the first one at the beginning
        val withoutDeclarations = xmlContent.replace(xmlDeclaration, "")
        val cleaned = withoutDeclarations.trimStart()

        return firstDeclaration + "\n" + cleaned
    }

    /**
     * Clean text content by removing HTML entities and normalizing
     */
    private fun cleanTextContent(text: String?): String {
        if (text.isNullOrBlank()) return ""

        return text
            // Remove HTML entities
            .replace("&amp;", "&")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&quot;", "\"")
            .replace("&#39;", "'")
            // Remove remaining HTML tags if any
            .replace(Regex("<[^>]+>"), "")
            // Trim whitespace
            .trim()
    }

    /**
     * Skip parser to the end of the specified tag
     */
    private fun skipToEndTag(parser: XmlPullParser, tagName: String) {
        try {
            var eventType = parser.eventType
            var depth = 1
            while (eventType != XmlPullParser.END_DOCUMENT && depth > 0) {
                eventType = parser.next()
                when (eventType) {
                    XmlPullParser.START_TAG -> {
                        if (parser.name == tagName) depth++
                    }
                    XmlPullParser.END_TAG -> {
                        if (parser.name == tagName) depth--
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error while skipping tag: $tagName", e)
        }
    }
    
    private fun parseTimestamp(timestamp: String?): Long {
        // Parse XMLTV format: YYYYMMDDHHmmss +0000
        // Example: "20231105143000 +0000" = Nov 5, 2023 14:30:00 UTC
        return try {
            if (timestamp == null || timestamp.length < 14) {
                Log.w(TAG, "Invalid timestamp: $timestamp")
                return System.currentTimeMillis()
            }
            
            // Extract date/time components from format: YYYYMMDDHHmmss
            val year = timestamp.substring(0, 4).toInt()
            val month = timestamp.substring(4, 6).toInt()
            val day = timestamp.substring(6, 8).toInt()
            val hour = timestamp.substring(8, 10).toInt()
            val minute = timestamp.substring(10, 12).toInt()
            val second = timestamp.substring(12, 14).toInt()
            
            // Create Calendar instance in UTC timezone
            val calendar = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC"))
            calendar.set(year, month - 1, day, hour, minute, second) // Month is 0-indexed
            calendar.set(java.util.Calendar.MILLISECOND, 0)
            
            val result = calendar.timeInMillis
            Log.d(TAG, "Parsed timestamp: $timestamp -> $result")
            result
        } catch (e: Exception) {
            Log.e(TAG, "Failed to parse timestamp: $timestamp", e)
            System.currentTimeMillis()
        }
    }
}
